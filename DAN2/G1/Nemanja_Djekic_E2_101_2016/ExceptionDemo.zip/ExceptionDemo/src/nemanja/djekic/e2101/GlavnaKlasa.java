package nemanja.djekic.e2101;

public class GlavnaKlasa {

	public static void main(String[] args) {
		
		MojaKlasa mojObj = new MojaKlasa();
		
		if(f1() != 0)
		{
			System.err.println("Negdje se desila greska!");
			return;
		}
		
		mojObj.pozitivniInt(-1);
		
		try
		{
			mojObj.nekaMetoda();
		}
		catch (EdukativniException e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static int f1()
	{
		int rezultat;
		int errorKod = f2();
		if(errorKod != 0)
		{
			return -1;
		}
		
		return 0;
	}
	
	public static int f2()
	{
		int rezultat;
		
		return 1;
	}

}
