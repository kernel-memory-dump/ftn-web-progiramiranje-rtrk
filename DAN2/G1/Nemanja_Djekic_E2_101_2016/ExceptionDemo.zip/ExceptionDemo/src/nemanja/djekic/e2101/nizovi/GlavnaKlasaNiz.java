package nemanja.djekic.e2101.nizovi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlavnaKlasaNiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[5];
		
		String[] x2 = new String[5];
		
		int[][] nizNizova = new int[5][];
		
		for (int i = 0; i < nizNizova.length; i++)
		{
			nizNizova[i] = new int[5];
			for (int j = 0; j < nizNizova[i].length; j++)
			{
				System.out.println("Niz:" + nizNizova[i][j]);
			}
		}
		
		for (int i = 0; i < x.length; i++) 
		{
			System.out.println("Niz[" + i + "]:" + x[i]);
		}
		
		x = new int[50];
		
		for (int i = 0; i < x2.length; i++) 
		{	
			x2[i] = "Neki string" + i;
			x2[i] = new String("Neki string" + i);
			System.out.println("Niz[" + i + "]:" + x2[i]);
		}
		
		//CTRL+SHIFT+O
		List<String> lista= new ArrayList<String>();
		
		lista.add("PRVI");
		lista.add("DRUGI");
		
		for (int i = 0; i < lista.size(); i++)
		{
			String element = lista.get(i);
			System.out.println(lista.get(i));
		}
		
		for (String element : lista)
		{
			System.out.println(element);
			lista.remove(element);
		}
		
		Map<String, Integer> mapa = new HashMap<>();
		mapa.put("BIJELO", 255);
		mapa.put("CRNO2", 0);
		
		System.out.println(mapa.get("BIJELO"));
		System.out.println(mapa.get("NEMA"));
		
		if (mapa.containsKey("CRNO"))
		{
			System.out.println("IMA GA!");
		}
		else
		{
			System.out.println("NEMA GA!");
		}
		
		if (mapa.get("CRNO") != null)
		{
			System.out.println("IMA GA!");
		}
		else
		{
			System.out.println("NEMA GA!");
		}
		
		for (String kljuc : mapa.keySet())
		{
			System.out.println("KLJUC JE:" + kljuc);
			System.out.println("VRIJEDNOST JE:" + mapa.get(kljuc));
		}
	}

}
