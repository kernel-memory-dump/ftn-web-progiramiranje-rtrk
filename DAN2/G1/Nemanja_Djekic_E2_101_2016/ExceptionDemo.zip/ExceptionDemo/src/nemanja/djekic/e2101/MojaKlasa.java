package nemanja.djekic.e2101;

public class MojaKlasa {
	
	public void nekaMetoda() throws EdukativniException
	{
		throw new EdukativniException("Poruka, GRESKA SE ZBILA!!!");
	}

	public void pozitivniInt(int i) 
	{
		if (i <= 0)
		{
			throw new IllegalArgumentException("Argument mora biti veci od 0");
		}
	}

}
