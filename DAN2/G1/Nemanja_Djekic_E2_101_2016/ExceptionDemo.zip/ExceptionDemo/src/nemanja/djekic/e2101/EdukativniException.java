package nemanja.djekic.e2101;

public class EdukativniException extends Exception {
	
	public EdukativniException (String msg)
	{
		super(msg);
	}

}
