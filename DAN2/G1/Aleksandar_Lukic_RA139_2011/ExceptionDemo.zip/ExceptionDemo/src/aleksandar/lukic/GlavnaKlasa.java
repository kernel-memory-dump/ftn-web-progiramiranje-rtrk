package aleksandar.lukic;

public class GlavnaKlasa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MojaKlasa mojObj = new MojaKlasa();
		
		mojObj.pozitivniInt(-1);
		
		try {
			mojObj.nekaMetoda();
		} catch (EdukativniException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
