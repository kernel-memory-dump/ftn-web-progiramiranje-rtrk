package aleksandar.lukic;

public class MojaKlasa {
	
	public void nekaMetoda() throws EdukativniException {
		
		throw new EdukativniException("Poruka, Greska se zbila");
	}

	public void pozitivniInt(int i) {
		// TODO Auto-generated method stub
		if(i <= 0){
			throw new IllegalArgumentException("argument mora biti > 0");
		}
		
	}
}
