package aleksandar.lukic.nizovi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlavnaKlasaNiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x =  new int[5];
		
		String[] x2 = new String[5];
		
		int[][] nizNizova = new int[5] [];
		
		
		for (int i = 0; i < nizNizova.length; i++) {
			nizNizova[i] = new int[5];
			for (int j = 0; j < nizNizova.length; j++) {
		
			System.out.println("niz:" + nizNizova[i][j]);
			
			}
		}
		
		for (int i = 0; i < x.length; i++) {
			System.out.println(" niz[" + i + "]:" + x[i]);
			
		}
		
		for (int i = 0; i < x2.length; i++) {
			x2[i] =  "Neki string" + i;
			x2[i] =  new String ("Neki string" + i);
			
			System.out.println(" niz[" + i + "]:" + x2[i]);
		}
		
		
		List<String> lista = new ArrayList<String>();
		
		lista.add("PRVI");
		lista.add("DRUGI");
		
		for(int i = 0; i <lista.size(); i++){
			System.out.println(lista.get(i));
		}
		
		Map<String,Integer> mapa = new HashMap<>();
		mapa.put("BELO", 255);
		mapa.put("CRNO2", 0);
		
		System.out.println(mapa.get("BELO"));
		
		//System.out.println(mapa.get("NEMA").toString());
		
		if(mapa.containsKey("CRNO")){
			
			System.out.println("IMA GA");
		}
		else
		{
			System.out.println("NEMA GA");
		}
		
		
		if(mapa.get("CRNO") != null)
		{
			System.out.println("IMA GA");
		}
		else
		{
			System.out.println("NEMA GA");
		}
		
		
		for(String kljuc : mapa.keySet())
		{
			System.out.println("KLJUC JE" + kljuc);
			System.out.println("VREDNOST JE:" + mapa.get(kljuc));
			
		}
	}


}
