package lazar.vukasovic;

public class EdukativniException extends Exception
{

	public EdukativniException(String msg)
	{
		super(msg);
	}

}
