package lazar.vukasovic.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class GlavnaSocketKlijent
{

	public static void main(String[] args)
	{
		Scanner skener = new Scanner(System.in);
		String unosKorisnika = skener.nextLine();
		System.out.println("Ucitano od korisnika " + unosKorisnika);
		
		/*
		String parMBTekst = null;
		StringBuilder bafer = new StringBuilder();
		for(int i = 0; i < 2000000; i++){
			bafer.append("|||");
		}
		
		bafer.append("\n");
		bafer.append(unosKorisnika);
		parMBTekst = bafer.toString();
		*/
		try
		{
			Socket vezaKaServeru = new Socket("10.81.35.60", 8080);
			OutputStream izlaz = vezaKaServeru.getOutputStream();
			PrintWriter rinter = new PrintWriter(izlaz);
			rinter.println(unosKorisnika);
			rinter.flush();
			vezaKaServeru.close();
			
			InputStream ulaz = vezaKaServeru.getInputStream();
			Scanner ulazniSkener = new Scanner(ulaz);
			
			
			
			System.out.println("Message sent");
	
			
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		
		skener.close();
	}

}
