package lazar.vukasovic.nizovi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class GlavnaKlasaNiz
{

	public static void main(String[] args)
	{
		int[] x = new int[5];

		String[] x2 = new String[5];

		int[][] nizNizova = new int[5][];

		for (int i = 0; i < nizNizova.length; i++)
		{
			nizNizova[i] = new int[5];
			for (int j = 0; j < nizNizova[i].length; j++)
			{
				System.out.println("niz:" + nizNizova[i][j]);
			}

		}

		for (int i = 0; i < x.length; i++)
		{
			System.out.println("niz[" + i + "]:" + x[i]);
		}

		for (int i = 0; i < x2.length; i++)
		{
			x2[i] = "neki string" + i;
			x2[i] = new String("Neki string" + i);
			System.out.println("niz[" + i + "]:" + x2[i]);
		}

		List<String> lista = new ArrayList<String>();

		lista.add("PRVI");
		lista.add("DRUGI");

		for (int i = 0; i < lista.size(); i++)
		{
			System.out.println(lista.get(i));
		}
		for (String element : lista)
		{
			System.out.println(element);
		}
	
	
		Map<String, Integer> mapa = new HashMap<>();
		mapa.put("BELO", 255);
		mapa.put("CRNO", 0);
		
		System.out.println(mapa.get("BELO"));
		
		//mapa.get("Crno) != null 
		if(mapa.containsKey("CRNO")){
			System.out.println("IMA GA");
		}else {
			System.out.println("NEMA GA");
		}
		
		for(String kljuc : mapa.keySet()){
			System.out.println("Kljuc: " + kljuc.toString()                                                                                                                                         );
		}
		
	
	
	
	}

}
