package lazar.vukasovic;

public class MojaKlasa
{

	public void nekaMetoda() throws EdukativniException
	{
		throw new EdukativniException("Greska se zbila");
	}

	public void pozitivniInt(int i)
	{
		if (i <= 0 ) {
			throw new IllegalArgumentException("Argument mora biti veci > 0");
		}
	}
}
