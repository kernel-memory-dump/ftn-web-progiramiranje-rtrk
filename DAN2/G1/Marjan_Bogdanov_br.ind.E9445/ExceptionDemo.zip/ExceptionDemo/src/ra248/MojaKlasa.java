package ra248;

public class MojaKlasa {
	public void nekaMetoda() throws EdukativniException{
		throw new EdukativniException("Poruka, GRESKA");
	}

	public void pozitivniInt(int i) {
		// TODO Auto-generated method stub
		if(i<=0){
			throw new IllegalArgumentException("Argument mora biti > 0");
		}
	}
}
