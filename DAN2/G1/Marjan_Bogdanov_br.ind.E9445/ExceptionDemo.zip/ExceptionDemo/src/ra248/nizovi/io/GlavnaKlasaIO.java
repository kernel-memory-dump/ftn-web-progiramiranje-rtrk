package ra248.nizovi.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GlavnaKlasaIO {

	public static void main(String[] args) {
		
		File mojFajl = new File("mojFile.txt");
		try {
			FileOutputStream fajlStream = new FileOutputStream(mojFajl);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try{
			FileOutputStream fajlStream1 = new FileOutputStream(mojFajl);
			BufferedOutputStream bafer = new BufferedOutputStream(fajlStream1);
			String mojString = "test upis";
			bafer.write(mojString.getBytes());
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		File mojFajl2 = new File("mojFajl2.txt");
		FileOutputStream fajlStream = new FileOutputStream(mojFajl2);
		PrintWriter printer = new PrintWriter(fajlStream);
		printer.println("Moj neki ispis");
		printer.close();
		
		Scanner skener = new Scanner(System.in);
		String unosKorisnika = skener.nextLine();
		System.out.println("UCITANO: " + unosKorisnika);
		skener.close();
		
		FileInputStream ulazniStream = new FileInputStream(mojFajl2);
		Scanner skenerZaFajl = new Scanner(ulazniStream);
		while(skenerZaFajl.hasNext()){
			String linija = skenerZaFajl.nextLine();
			System.out.println(linija);
		}
		skenerZaFajl.close();
	}

}
