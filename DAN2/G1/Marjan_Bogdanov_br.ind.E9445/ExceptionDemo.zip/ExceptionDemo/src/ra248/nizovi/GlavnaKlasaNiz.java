package ra248.nizovi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlavnaKlasaNiz  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[5];
		String[] x2 = new String[5];
		int[][] nizNizova = new int[5] [];
		
		for(int i=0; i<x.length; i++){
			nizNizova[i] = new int[5];
			for(int j=0; j<nizNizova[i].length; j++){
				System.out.println("niz:" + nizNizova[i][j]);
			}
		}
		
		x = new int[50];
		
		for(int i=0; i<x2.length; i++){
			x2[i] = "Neki string" + i;
			x2[i] = new String("Neki string" + i);
			System.out.println("niz [" + i + "]:" + x2[i]);
		}
		
		
		
		//ctrl+shift+o
		List<String> lista = new ArrayList<String>();
		lista.add("prvi");
		lista.add("drugi");
		
		for(int i=0; i<lista.size(); i++){
			String element = lista.get(i);
			System.out.println(element);
		}
		
		for(String element : lista){
			System.out.println(element);
		}
		
		Map<String, Integer> mapa = new HashMap<String, Integer>();
		mapa.put("belo", 255);
		mapa.put("crno", 0);
		
		System.out.println(mapa.get("belo"));
		
		System.out.println(mapa.get("nema").toString());
		
		if(mapa.containsKey("crno")){
			System.out.println("ima ga");
		}else{
			System.out.println("nema ga");
		}
		
		for(String kljuc : mapa.keySet()){
			System.out.println("kljuc je: " + kljuc);
			System.out.println("vrednost je: " + mapa.get(kljuc));
		}
		
		
		
		
		
	}
	
}
