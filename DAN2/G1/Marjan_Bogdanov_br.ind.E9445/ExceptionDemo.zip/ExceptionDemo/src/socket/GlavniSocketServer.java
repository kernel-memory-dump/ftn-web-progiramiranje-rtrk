package socket;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import org.omg.CORBA.portable.OutputStream;

public class GlavniSocketServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner skener = new Scanner(System.in);
		String unosKorisnika = skener.nextLine();
		System.out.println("Ucitano" + unosKorisnika);
		skener.close();
		
		String parMBTeksta = null;
		StringBuilder builder = new StringBuilder();
		
		for(int i=0; i<2000; i++){
			builder.append("a");
		}
		builder.append("\n");
		builder.append(unosKorisnika);
		parMBTeksta = builder.toString();
		
		
		try{
			Socket vezaKaServeru = new Socket("10.81.35.57",8080);
			OutputStream izlaz = vezaKaServeru.getOutputStream();
			PrintWriter printer = new PrintWriter(izlaz);
			printer.println(parMBTeksta);
			//printer.flush();
			//vezaKaServeru.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
