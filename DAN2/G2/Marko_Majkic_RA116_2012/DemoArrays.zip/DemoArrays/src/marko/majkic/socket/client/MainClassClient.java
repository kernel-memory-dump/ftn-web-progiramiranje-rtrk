package marko.majkic.socket.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class MainClassClient {

	public static void main(String[] args) throws UnknownHostException, IOException {
	
		Socket serverConnect = new Socket("10.81.35.60", 8080);
		OutputStream outputStream = serverConnect.getOutputStream();
		InputStream inputStream = serverConnect.getInputStream();
		
		Scanner scanner = new Scanner(System.in);
		String message = scanner.nextLine();
		PrintWriter printer = new PrintWriter(outputStream);
		
		printer.println(message);
		printer.flush();
		printer.close();
		
		InputStreamReader reader = new InputStreamReader(inputStream);
		BufferedReader buffereReader = new BufferedReader(reader);
		String line = null;
		
		while((line = buffereReader.readLine()) != null)
		{
			System.out.println(line);
		}
		
	}

}
