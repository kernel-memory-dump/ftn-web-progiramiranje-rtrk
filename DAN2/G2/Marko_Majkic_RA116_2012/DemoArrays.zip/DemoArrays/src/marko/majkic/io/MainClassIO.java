package marko.majkic.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MainClassIO {

	public static void main(String[] args) throws IOException {
		
		File file = new File("MyFile.txt");
		
		try {
			FileOutputStream outputStream = new FileOutputStream(file);
			BufferedOutputStream bufferedOutput = new BufferedOutputStream(outputStream);
			
			String someText = "TEXT_TO_FILE";
			
			bufferedOutput.write(someText.getBytes());
			bufferedOutput.flush();
			
			bufferedOutput.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			/*param [true] continue writing on existing file*/
			FileOutputStream outputStream = new FileOutputStream(file, true);
			PrintWriter printer = new PrintWriter(outputStream);
			
			printer.write("/TEXT IN NEW FILE");
			printer.flush();
			printer.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		Scanner keyboard = new Scanner(System.in);
		
		String myInput = keyboard.nextLine();
		System.out.println("Your input is: " + myInput);
		
		keyboard.close();
		
		FileInputStream inputStream = new FileInputStream(file);
		Scanner scanFromFile = new Scanner(inputStream);
		
		while (scanFromFile.hasNext()) {
			System.out.println(scanFromFile.nextLine());			
		}
		
		scanFromFile.close();
	}
}
