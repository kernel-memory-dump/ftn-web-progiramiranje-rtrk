package marko.majkic.arrays;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainClassArrays {

	public static void main(String[] args) {
		int[] myArray = new int[5];

		String[] stringArray = new String[3];
		
		for (int i = 0; i < myArray.length; i++)
		{
			System.out.println(myArray[i]);
		}

		for (int i = 0; i < stringArray.length; i++) {
			stringArray[i] = "" + i;
			System.out.println(stringArray[i]);
		}
		
		myArray = new int[4];
		
		List<String> myList = new ArrayList<>();
		
		myList.add("NEW_ELEMENT_1");
		myList.add("NEW_ELEMENT_2");
		myList.add("NEW_ELEMENT_3");
		
		for(int i = 0; i <myList.size(); i++)
		{
			String element = myList.get(i);
			System.out.println(element);
		}
		
		//myList.remove(0); 				//removes element[0] element
		//myList.add("NEW NEW ELEMENT");	//add new element on end
		myList.set(0, "NEW_ELEMENT_SET");	//set new value to element[0]
		
		for (String string : myList) 
		{
			System.out.println(string);
		}
		
		// key, value
		Map<String, Integer> myMap = new HashMap<>();
		
		myMap.put("RED", 255);
		myMap.put("WHITE", 0);
		
		System.out.println(myMap.get("RED"));		//print key value
		System.out.println(myMap.get("WHITE"));		//print key value
		System.out.println(myMap.get("FAKE"));		//null printed
		
		if(myMap.get("RED") != null)
		{
			System.out.println("TRUE KEY: " + "RED");
		}
		else
		{
			System.out.println("FALSE KEY");
		}
		
		for (String key : myMap.keySet()) 
		{
			System.out.println("VALUE IS: " + myMap.get(key));
			
		}
		
	}

}
