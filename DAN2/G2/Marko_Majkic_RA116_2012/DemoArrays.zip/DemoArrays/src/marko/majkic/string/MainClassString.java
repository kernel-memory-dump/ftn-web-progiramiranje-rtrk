package marko.majkic.string;

public class MainClassString {

	public static void main(String[] args) {
		String test = "abc";
		test = test.replace("a", "1");
		
		System.out.println(test);

		String test2 = "abc";
		String test3 = new String("abc");
		
		if(test2 == test3)
		{
			System.out.println("Equal = TRUE");
		}
		else
		{
			System.out.println("Equal = FALSE");
		}
		
		if(test2.equals(test3))
		{
			System.out.println("Equal = TRUE");
		}
		else
		{
			System.out.println("Equal = FALSE");
		}
		
		StringBuilder stringBuilder = new StringBuilder();
		
		for (int i = 0; i < 10; i++) {
			stringBuilder.append("A");
		}
		
		String finalString = stringBuilder.toString();
		System.out.println(finalString);
		
	}

}
