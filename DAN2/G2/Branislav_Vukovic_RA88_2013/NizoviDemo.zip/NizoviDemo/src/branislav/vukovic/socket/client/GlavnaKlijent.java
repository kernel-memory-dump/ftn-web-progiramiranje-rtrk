package branislav.vukovic.socket.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class GlavnaKlijent {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub

		Socket vezaKaServeru = new Socket("10.81.35.60", 8080);
		OutputStream izlazniStream = vezaKaServeru.getOutputStream();
		InputStream ulazniStream = vezaKaServeru.getInputStream();

		Scanner skener = new Scanner(System.in);
		String porukaZaServer = skener.nextLine();

		PrintWriter printer = new PrintWriter(izlazniStream);
		printer.println(porukaZaServer);
		printer.flush();
		printer.close();

		InputStreamReader reader = new InputStreamReader(ulazniStream);
		BufferedReader baferovan = new BufferedReader(reader);
		String line = null;

		while ((line = baferovan.readLine()) != null) {
			System.out.println(line);
		}

	}

}
