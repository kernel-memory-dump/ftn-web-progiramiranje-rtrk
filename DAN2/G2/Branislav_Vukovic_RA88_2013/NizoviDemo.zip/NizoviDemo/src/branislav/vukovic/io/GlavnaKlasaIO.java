package branislav.vukovic.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GlavnaKlasaIO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File fajl = new File("MojFajl.txt");
		try {
			FileOutputStream izlazniStream = new FileOutputStream(fajl);
			BufferedOutputStream baferovanIzlaz = new BufferedOutputStream(izlazniStream);
			String nekiTekst = "IDE U FAJL\n";
			
			baferovanIzlaz.write(nekiTekst.getBytes());
			baferovanIzlaz.flush();
			
			baferovanIzlaz.close(); 
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			FileOutputStream izlazniStream = new FileOutputStream(fajl, true);
			PrintWriter printer = new PrintWriter(izlazniStream);
			printer.println("Printer linija");
			printer.flush();
			printer.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Scanner tastatura = new Scanner(System.in);
		String mojUnos = tastatura.nextLine();
		System.out.println("Uneli smo:" + mojUnos);
		tastatura.close();
		
		FileInputStream ulazniStream = null;
		
		try {
			ulazniStream = new FileInputStream(fajl);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scanner izFajla = new Scanner(ulazniStream);
		while (izFajla.hasNext()) {				
			System.out.println(izFajla.nextLine());		
		}
		izFajla.close();

	}

}
