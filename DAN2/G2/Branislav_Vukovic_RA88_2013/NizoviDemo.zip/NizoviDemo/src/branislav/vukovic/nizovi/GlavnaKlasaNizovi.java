package branislav.vukovic.nizovi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlavnaKlasaNizovi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] mojNiz = new int[5];
		
		String[] stringNiz = new String[3];
		
		for (int i = 0; i < mojNiz.length; i++) {
			System.out.println(mojNiz[i]);
		}
		for (int i = 0; i < stringNiz.length; i++) {
			stringNiz[i] = "" + i;
			System.out.println(stringNiz[i]);
		}
		
		mojNiz = new int[4];
		List<String> lista = new ArrayList<>();
		lista.add("Novi Element 1");
		lista.add("Novi Element 2");
		
		for (int i = 0; i < lista.size(); i++) {
			String element = lista.get(i);
			System.out.println(element);
		}
		
		lista.set(0, "nesto sasvim novo");
		
		for (String string : lista) {
			System.out.println(string);
		}
		
		Map<String, Integer> mapa = new HashMap<>();
		mapa.put("crveno", 255);
		mapa.put("belo", 0);
		
		System.out.println(mapa.get("crveno"));
		System.out.println(mapa.get("belo"));
		
		System.out.println(mapa.get("nema"));
		
		if (mapa.get("crveno") != null) {
			System.out.println("ima ga");
		}else {
			System.out.println("nema ga");
		}
		
		if (mapa.containsKey("crveno2")) {
			System.out.println("ima ga");
		}else {
			System.out.println("nema ga");
		}
		
		for (String kljuc : mapa.keySet()) {
			System.out.println("kljuc je:" + kljuc);
			System.out.println("vrednost je:" + mapa.get(kljuc));
			
		}
	}
	

}
