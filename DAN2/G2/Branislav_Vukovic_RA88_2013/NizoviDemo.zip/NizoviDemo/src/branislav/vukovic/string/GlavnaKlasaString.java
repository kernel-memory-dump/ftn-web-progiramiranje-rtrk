package branislav.vukovic.string;

public class GlavnaKlasaString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String test = "abc";
		test = test.replace("a", "1");
		System.out.println(test);

		String test2 = "abc";
		String test3 = new String("abc");

		if (test2 == test3) {
			System.out.println("jednaki su");

		} else {

			System.out.println("nisu jednaki");
		}

		if (test2.equals(test3)) {
			System.out.println("jednaki su");

		} else {

			System.out.println("nisu jednaki");
		}
		
		StringBuilder builder = new StringBuilder();
		for(int i = 0; i<10;i++){
			builder.append("A");
			
		}
		String konacno = builder.toString();
		System.out.println(konacno);

	}

}
