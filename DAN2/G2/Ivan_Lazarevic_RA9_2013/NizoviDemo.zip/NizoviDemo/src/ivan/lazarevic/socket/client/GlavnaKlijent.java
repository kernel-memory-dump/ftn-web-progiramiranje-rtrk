package ivan.lazarevic.socket.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


public class GlavnaKlijent {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		Socket veza = new Socket("10.81.35.60", 8080);
		OutputStream izlazni = veza.getOutputStream();
		Scanner skener = new Scanner(System.in);
		String poruka = skener.nextLine();
		
		InputStream ulazni = veza.getInputStream();
		
		
		PrintWriter printer = new PrintWriter(izlazni);
		printer.println(poruka);
		printer.flush();
		printer.close();
		
		InputStreamReader reader = new InputStreamReader(ulazni);
		BufferedReader baferovan = new BufferedReader(reader);
		String line = null;
		
		while((line = baferovan.readLine()) != null){
			System.out.println(line);
		}

	}

}
