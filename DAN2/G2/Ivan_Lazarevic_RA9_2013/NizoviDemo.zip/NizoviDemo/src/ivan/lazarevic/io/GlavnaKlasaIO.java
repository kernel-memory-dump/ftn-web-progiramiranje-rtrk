package ivan.lazarevic.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GlavnaKlasaIO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File fajl = new File ("MojFajl.txt");
		
		try {
			FileOutputStream izlazniStream = new FileOutputStream(fajl);
			BufferedOutputStream baferovaniIzlaz = new BufferedOutputStream(izlazniStream);
			String tekst = "ide u fajl\n";
			baferovaniIzlaz.write(tekst.getBytes());
			baferovaniIzlaz.flush();
			
			baferovaniIzlaz.close();
			
		} catch (FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
		
		try {
			FileOutputStream izlazniStream = new FileOutputStream(fajl, true);//false i gazi prethodni
			PrintWriter printer = new PrintWriter(izlazniStream);
			printer.println("printer linija");
			printer.flush();
			printer.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Scanner tastatura = new Scanner(System.in);
		String unos = tastatura.nextLine();
		System.out.println("unos: "+ unos);
		tastatura.close();
		
		FileInputStream ulazni = null;
		
		try {
			ulazni = new FileInputStream(fajl);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scanner izFajla = new Scanner(ulazni);
		while(izFajla.hasNext()){
			System.out.println(izFajla.nextLine());
		}
		izFajla.close();
	}

}
