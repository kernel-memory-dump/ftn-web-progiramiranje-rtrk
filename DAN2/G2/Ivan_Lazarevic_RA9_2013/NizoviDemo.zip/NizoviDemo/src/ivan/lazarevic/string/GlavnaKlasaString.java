package ivan.lazarevic.string;

public class GlavnaKlasaString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String test = "abc";
		test = test.replace("a", "1");
		System.out.println(test);
		
		String test2 = "abc";
		String test3 = new String("abc");
		
		if(test2 == test3){
			System.out.println("jednaki");
		}else {
			System.out.println("nisu jednaki");
		}
		
		if(test2.equals(test3)){
			System.out.println("jednaki");
		}else {
			System.out.println("nisu jednaki");
		}
		
		StringBuilder bilder = new StringBuilder();
		for (int i=0; i < 10; i++){
			bilder.append("A");
		}
		String konacno = bilder.toString();
		System.out.println(konacno);
	}

}
