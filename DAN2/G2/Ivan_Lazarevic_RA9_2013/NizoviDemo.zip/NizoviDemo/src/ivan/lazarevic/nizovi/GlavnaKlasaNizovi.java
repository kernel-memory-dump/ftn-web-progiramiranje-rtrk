package ivan.lazarevic.nizovi;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlavnaKlasaNizovi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] mojNiz = new int[5];
		for (int i = 0; i < mojNiz.length; i++) {
			System.out.println(mojNiz[i]);
		}
		
		String[] stringNiz = new String[3]; 
		for (int i = 0; i < stringNiz.length; i++) {
			stringNiz[i] = "" + i;
			System.out.println(stringNiz[i]);
		}
		mojNiz = new int[4];
		
		List<String> lista = new ArrayList<>();
		lista.add("novi element 1");
		lista.add("novi element 2");
		lista.add("novi element 3");
		
		for(int i = 0; i < lista.size(); i++)
		{
			String element = lista.get(i);
			System.out.println(element);
		}
		
		lista.set(0, "setovano");
		
		for (String string : lista)
		{
			System.out.println(string);
		}
		
		//key, value
		Map<String, Integer>  mapa = new HashMap<>();
		mapa.put("crno",255);
		mapa.put("belo", 0);
		
		System.out.println(mapa.get("crno"));
		System.out.println(mapa.get("belo"));
		
		System.out.println(mapa.get("nema"));
		
		if(mapa.get("crno") != null)
		{
			System.out.println("ima");
		}
		else
		{
			System.out.println("nema");
		}
		
		
		if(mapa.containsKey("crno"))
		{
			System.out.println("ima");
		}
		else
		{
			System.out.println("nema");
		}	
		for (String kljuc : mapa.keySet())
		{
			System.out.println("kljuc je: " + kljuc);
			System.out.println("vrednost je: " + mapa.get(kljuc));
		}
		
	}
}


