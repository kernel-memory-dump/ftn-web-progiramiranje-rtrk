package branislav.vukovic.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import branislav.vukovic.dao.UserDao;
import branislav.vukovic.model.User;

/**
 * Servlet implementation class DodajkorisnikaServlet
 */
public class DodajkorisnikaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DodajkorisnikaServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setStatus(400);
	}

	/**
	 * @throws IOException
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ime = request.getParameter("ime");
		String tip = request.getParameter("tip");

		if (ime == null || tip == null) {
			response.setStatus(400);
			return;
		}
		System.out.println("Ime osobe je: " + ime + " tip osobe je: " + tip);
		User novi = new User(ime, tip);
		PrintWriter printer = response.getWriter();
		List<User> users = null;
		try {
			UserDao.adduser(novi);
			users = UserDao.getAllUsers();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			printer.print("<html><body><h1>Greska pri dodavanju korisnika!</h1></body></html>");
			e.printStackTrace();
			printer.flush();
			printer.close();
			return;
		}
		String htmlZaKlijenta = browserResponse(users);
		printer.write(htmlZaKlijenta);

	}

	/**
	 * Generisanje odgovora za web browser
	 */
	private static String browserResponse(List<User> users) {
		String retVal = "";
		retVal += "<html><head><title>Prijavljeni korisnici</title></head>\n";
		retVal += "<body><h1>Prijavljeni korisnici</h1><ol>\n";
		for (int i = 0; i < users.size(); i++) {
			User user = users.get(i);
			retVal += "<li>" + user.getIme() + "</li>\n";
		}
		retVal += "</ol></body></html>\n";
		return retVal;
	}

}
